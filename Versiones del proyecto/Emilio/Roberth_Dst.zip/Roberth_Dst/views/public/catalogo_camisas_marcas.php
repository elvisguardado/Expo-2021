<?php
//Se incluye la clase con plantillas del documento.
include("../../app/helpers/public/plantilla_public.php");
//Se imprime la plantilla del encabezado y se establece el titulo para la pagina web.
Planilla_Public::headerTemplate('Principal');
?>

<div class="container">

    <div class="row">

        <!--Combobox para la busqueda y filtrado de las marcas.-->
        <form id="search_combo">

            <p id="labelCombo">Seleccione la marca deseada:</p>

            <!--Columna para el comboBox-->
                <div class="input-field col s12">

                    <select class="browser-default" id="search_combo_style">
                        <option value="1">Camisetas marca Adidas</option>
                        <option value="2">Camisetas marca Aeropostal</option>
                        <option value="3">Camisetas marca Converse</option>
                        <option value="4">Camisetas marca Ecko</option>
                        <option value="5">Camisetas marca Emporio</option>
                        <option value="6">Camisetas marca Fox</option>
                        <option value="7">Camisetas marca Hurley</option>
                        <option value="8">Camisetas marca Jordan</option>
                        <option value="9">Camisetas marca Marcas Mixtas</option>
                        <option value="10">Camisetas marca Nike</option>
                        <option value="11">Camisetas marca Puma</option>
                        <option value="12">Camisetas marca QuickSilver</option>
                        <option value="13">Camisetas marca Ripcurl</option>
                        <option value="14">Camisetas marca Supreme</option>
                        <option value="15">Camisetas marca Vans</option>
                        <option value="16">Camisetas marca Volcom</option>
                    </select>

                </div>
        </form>

    </div>

</div>


<div class="container" id="bloqueCards">

    <!--Estructura del catalogo, primera fila-->
    <div class="row">

        <!--Primera columna-->
        <div class="col s12 m6 l6">
            <!--Primera Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img
                        src="../../resources/img/Trabajo_Pagina_Principal/Camisas/Camisas Marcas/Adidas/Adidas 3 Lineas.jpg" height="662">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>Adidas 3 Lineas</strong>
                    </p>
                </div>
            </div>
        </div>

        <!--Segunda columna-->
        <div class="col s12 m6 l6">
            <!--Segunda Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img src="../../resources/img/Trabajo_Pagina_Principal/Camisas/Camisas Marcas/Adidas/Adidas Barra.jpg"
                        height="662">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>Adidas Barra</strong>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!--Estructura del catalogo, segunda fila-->
    <div class="row">

        <!--Tercera columna-->
        <div class="col s12 m6 l6">
            <!--Primera Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img
                        src="../../resources/img/Trabajo_Pagina_Principal/Camisas/Camisas Marcas/Adidas/Adidas Basquet.jpg" height="662">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>Adidas Basquet</strong>
                    </p>
                </div>
            </div>
        </div>

        <!--Cuarta columna-->
        <div class="col s12 m6 l6">
            <!--Segunda Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img src="../../resources/img/Trabajo_Pagina_Principal/Camisas/Camisas Marcas/Adidas/Adidas Hoja Estrella.jpg"
                    height="662">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>Adidas Hoja Estrella</strong>
                    </p>
                </div>
            </div>
        </div>
    </div>

</div>

<?php
//Se imprime la plantilla del pie de pagina y se establece el controlador para la pagina web.
Planilla_Public::footerTemplate('catalogo_camisas_marcas.js');
?>