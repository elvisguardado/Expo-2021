<?php
//Se incluye la clase con plantillas del documento.
include("../../app/helpers/public/plantilla_public.php");
//Se imprime la plantilla del encabezado y se establece el titulo para la pagina web.
Planilla_Public::headerTemplate('Principal');
?>

<div class="container">

    <div class="row">

        <!--Combobox para la busqueda y filtrado de las marcas.-->
        <form id="search_combo">

            <p id="labelCombo">Seleccione la temática deseada:</p>

            <!--Columna para el comboBox-->
            <div class="input-field col s12">

                <select class="browser-default" id="search_combo_style">
                    <option value="1">Camisetas sobre BTS</option>
                    <option value="2">Camisetas sobre Buhos</option>
                    <option value="3">Camisetas sobre Frases</option>
                    <option value="4">Camisetas sobre Gatos</option>
                    <option value="5">Camisetas sobre Girasol</option>
                    <option value="6">Camisetas sobre Mickey</option>
                    <option value="7">Camisetas sobre Comida</option>
                    <option value="8">Camisetas sobre Stich</option>
                    <option value="9">Camisetas sobre Bob Esponja</option>
                    <option value="10">Camisetas sobre Osos</option>
                    <option value="10">Camisetas sobre SuperHeroes</option>
                    <option value="10">Camisetas sobre Snoopy</option>
                    <option value="10">Camisetas random</option>
                </select>

            </div>
        </form>

    </div>

</div>


<div class="container" id="bloqueCards">

    <!--Estructura del catalogo, primera fila-->
    <div class="row">

        <!--Primera columna-->
        <div class="col s12 m6 l6">
            <!--Primera Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img src="../../resources/img/Trabajo_Pagina_Principal/Blusas/Blusas Muñecos/BTS/BTS Manos.jpg" height="550">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>BTS Manos</strong>
                    </p>
                </div>
            </div>
        </div>

        <!--Segunda columna-->
        <div class="col s12 m6 l6">
            <!--Segunda Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img src="../../resources/img/Trabajo_Pagina_Principal/Blusas/Blusas Muñecos/BTS/BTS Mascotas.jpg" height="550">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>BTS Mascotas</strong>
                    </p>
                </div>
            </div>
        </div>       

    </div>

    <!--Estructura del catalogo, segunda fila-->
    <div class="row">

        <!--Tercera columna-->
        <div class="col s12 m6 l6">
            <!--Primera Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img
                        src="../../resources/img/Trabajo_Pagina_Principal/Blusas/Blusas Muñecos/BTS/BTS Rostro.jpg" height="550">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>BTS Rostro</strong>
                    </p>
                </div>
            </div>
        </div>

        <!--Cuarta columna-->
        <div class="col s12 m6 l6">
            <!--Segunda Card-->
            <div class="card">
                <!--Imagen de la Card-->
                <div class="card-image">
                    <img src="../../resources/img/Trabajo_Pagina_Principal/Blusas/Blusas Muñecos/BTS/BTS Manos.jpg" height="550">
                </div>
                <!--Contenido de la Card-->
                <div class="card-content center">
                    <p>
                        <strong>PENDIENTE DE CAMBIAR</strong>
                    </p>
                </div>
            </div>
        </div>   

    </div>

</div>

<?php
//Se imprime la plantilla del pie de pagina y se establece el controlador para la pagina web.
Planilla_Public::footerTemplate('catalogo_blusas_munecos.js');
?>